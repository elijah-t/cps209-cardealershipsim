Elijah's Car Dealership Simulator

Commands that work:

    L - Display inventory
    Q - Quit program
    BUY index - Buys a car from the inventory with the associated index
    RET - Return last bought car
    ADD - Adds new cars
    SPR - Sort by price (lowest to highest)
    SSR - Sort by safety rating (highest to lowest)
    SMR - Sort by max range (highest to lowest)
    FPR minimumPrice maximumPrice - Filters the cars by minimum price to maximum price
    FEL - Filters the cars by electric cars
    FAW - Filters the cars by AWD
    FCL - Clears filters